extends CharacterBody3D

#inputs
@export_group("Input Actions")
## Name of Input Action to move Left.
@export var input_left : String = "ui_left"
## Name of Input Action to move Right.
@export var input_right : String = "ui_right"
## Name of Input Action to move Forward.
@export var input_forward : String = "ui_up"
## Name of Input Action to move Backward.
@export var input_back : String = "ui_down"
## Name of Input Action to Jump.
@export var input_jump : String = "ui_accept"
## Name of Input Action to Sprint.
@export var input_slide : String = "sprint"
## Name of Input Action to dash.
@export var input_dash : String = "dash"
## Name of Input Action to toggle freefly mode.
@export var input_freefly : String = "freefly"
## Name of Input Action to shoot.
@export var input_shoot : String = "shoot"

@export_group("Speeds")
## Base speed
@export var BASE_SPEED: float = 5.0
## Sensitivity
@export var SENSITIVITY: float = 0.0025
## Jump Speed
@export var JUMP_VELOCITY: float = 6
## Sliding Speed
@export var SLIDE_VELOCITY: float = 12
## Walljump Speed
@export var WALLJUMP_SPEED: float = 18.0
## Dash Speed/Range
@export var DASH_SPEED: float = 30.0

var mouse_captured : bool = false

var move_speed : float = 0.0

#sliding
var is_sliding : bool = false
var slide_direction : Vector3 = Vector3.ZERO

#dashig
var is_dashing : bool = false
var dash_dir: Vector3 = Vector3.ZERO


#Camera rotating
var rot_x = 0
var rot_y = 0

#Walljumps
var walljump_count = 0

## IMPORTANT REFERENCES
@onready var head: Node3D = $Head
@onready var collider: CollisionShape3D = $Collider
@onready var gun_arm: Node3D = $Head/GunArm

func _ready() -> void:
	pass

func _unhandled_input(event: InputEvent) -> void:
	# Mouse capturing
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		capture_mouse()
	if Input.is_key_pressed(KEY_ESCAPE):
		release_mouse()
	
	# Look around
	if mouse_captured and event is InputEventMouseMotion:
		# modify accumulated mouse rotation
		rot_x -= event.relative.x * SENSITIVITY
		rot_y -= event.relative.y * SENSITIVITY
		transform.basis = Basis() # reset rotation
		rotate_y(rot_x) #rotate in X
		head.transform.basis = Basis()
		head.rotate_x(rot_y) #then in Y
		head.rotation.x = clamp(head.rotation.x, deg_to_rad(-80), deg_to_rad(80))
	
	#Shooting
	if mouse_captured and event.is_action_pressed(input_shoot):
		print("shoot")
	
	#Sliding (make the camera raising/lowering better, rn it relies on being/not being to the ground and thats bad)
	if event.is_action_pressed(input_slide):
		if is_on_floor():
			is_sliding = true
			
			var input_dir := Input.get_vector(input_left, input_right, input_forward, input_back)
			slide_direction = (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
			
			if slide_direction == Vector3.ZERO:
				slide_direction = -transform.basis.z
		
			head.position.y /= 2.3 #change this value to change how low the cam is during slide, change this in the release portion of slide logic aswell
			collider.shape.set_height(0.9)
			collider.position.y /= 2
		else:
			velocity.y -= 50
			print("GROUNDSLAM")
	if event.is_action_released(input_slide) and is_sliding:
		is_sliding = false
		head.position.y *= 2.3
		collider.shape.set_height(1.8)
		collider.position.y *= 2
	
	if event.is_action_pressed(input_dash):
		var input_dir := Input.get_vector(input_left, input_right, input_forward, input_back)
		var dash_dir = (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
		velocity += dash_dir*DASH_SPEED

func _physics_process(delta: float) -> void:
	# Apply gravity to velocity, also reset walljumps
	if not is_on_floor():
		velocity += get_gravity() * delta
	else:
		walljump_count = 0

	# Apply jumping/walljumping
	if Input.is_action_just_pressed(input_jump):
		if is_on_floor():
			velocity.y = JUMP_VELOCITY
		elif is_on_wall() and walljump_count < 3:
			var wall_normal = get_wall_normal()
			velocity = wall_normal * WALLJUMP_SPEED
			print(wall_normal * WALLJUMP_SPEED)
			velocity.y += JUMP_VELOCITY
			
			walljump_count += 1
			if walljump_count == 3:
				pass#play sound TBD

	# Lower camera and increase speed when sliding
	if is_sliding:
			move_speed = SLIDE_VELOCITY
			velocity.x = slide_direction.x * move_speed
			velocity.z = slide_direction.z * move_speed
			move_and_slide()
			return
	else:
		move_speed = BASE_SPEED

	#Get input dir and apply it to velocity
	var input_dir := Input.get_vector(input_left, input_right, input_forward, input_back)
	var move_dir := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	if is_on_floor():
		if move_dir:
			velocity.x = move_dir.x * move_speed
			velocity.z = move_dir.z * move_speed
		else:
			#slow down if no input
			velocity.x = move_toward(velocity.x, 0, move_speed)
			velocity.z = move_toward(velocity.z, 0, move_speed)
	else:
		velocity.x = lerp(velocity.x, move_dir.x * move_speed, delta * 7)
		velocity.z = lerp(velocity.z, move_dir.z * move_speed, delta * 7)

	# Use velocity to actually move
	move_and_slide()

func capture_mouse():
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	mouse_captured = true


func release_mouse():
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	mouse_captured = false
